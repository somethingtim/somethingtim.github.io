function start()
{alert("You have moved to a house. You woke up. hint, the world is full of dangers. Make sure you follow the typing instructions!");
var q1= prompt("should I stay in bed or go tolite? Type in 'bed' or 'tolite'");
 
if (q1 =="tolite") {
  alert("you went to the loo 'oh what a sunny day...' you said. Suddennly, you slipped and fell out of the windows. GAME OVER, GOOD TRY");
} else if(q1 =="bed"){
  var q2= prompt("you heard some noise from the bed you SUSPECT a THIEF under your bed. You can choose to ignore or spray croach killer or take a clear look or call the poliece or prepare to fight. Type in ignore/ spray/ poliece/ look/ fight");
}
  
if(q2=="ignore"){
   var q3=prompt ("you ignored the bed. Suddennly, a big shadow appeared behind you! he used one hand to cover your mouth.you can attempt escape or bite his hand or attempt to take phone and callpoliece. Type in escape/bite/poliece"); 
  if(q3=="escape"){
  alert ("you attempt escape and tripped the thief, unluckily the thief fell on you and both of you fell out of the windows GAME OVER nice try!");
}//end ignore if
  else if (q3=="bite"){
   var q3a=prompt ("you bit his hand he shouted and unexpect you to be so agressive. He is kind of scared of you and escape in full speed. You cosidered chasing the thief or stay as there is not much to steal under the bed. Type in chase/stay");
   if(q3a=="chase"){
     var q3a1= prompt ("the thief started running across a five laned road with a speeding truck at the end of the road. You can take the risk and the perfect chance to captue the thief as the thief got distracted by the truck or you choose not to take the risk of getting crushed by the truck. Type in chase/stay");
     if(q3a1=="stay") {
       alert ("the truck driver was being distracted'crrrccuuuncckkk''what noise? never mind'the driver stopped the car.'WAIT THERE IS A POKEMON HERE'the driver parked the truck there. And for the noise? they parked the truck right on top of the thief squashing the thief flat.YOU 'WON' THE SCARY WAY.");
     }else if(q3a1=="chase"){
       alert ("CRASH 'cruel world...' GAME OVER YOU ARE REALLY CLOSE TO WINNING!!!!!!!");
     }
   }else if(q3a=="stay"){
     alert ("YOU WON THE GENEROUS WAY")
   }
  }else if(q3=="poliece"){
    var q3a=prompt ("You must choose a phone but...a new note7 or an old broken phone. Type in note7/ old phone")
  if (q3a=="note7"){
    alert ("with trembling hands you hoped for the best. suddennly you heard footsteps from the corriddor. the thief probbally have a gun... you spanned your note7 in full speed just when you nearly typed the last 9 the thief jumped out of the corner and snatched your phone. 'don't you dare to call the cops' just then the note7 burnt through its shell and blew up right in the thief's hand! The supreme timing and thinking of you made YOU WON THE WISE WAY.");
  }
  else if(q3a=="old phone") {
    alert ("your brick phone nokia is famous for bullet proof and undestructable! surely it wouldn't fail you. Yet, your phone didn't fail you but your charger did. you heard the thief running down the hallway. with fustration, you threw the phone out of the windows with full strength. but your aim was too good and hit the thief right in the head! the thief fell down fainted. YOU WON THE EPIC WAY!");
  }
  }
  else {
    alert("make sure you followed the typing instructions. please restart game");
}//end of q2 else
} else if (q2=="spray"){
   var q4=prompt("you sprayed the thief! he climbed out under the bed he covered his eye and his face. you can keep spraying or punch or kick. Type in spray/punch/kick");
      if(q4=="spray"){
  var q5=prompt ("The thief surrendered, he gave you and offer and tried to bribe you with half of his life time stolen treasures. you can accept offer and not tell this secret to anyone or capture him and leave him to the poliece Type in offer/capture");
  if(q5=="offer"){
        alert ("the thief gave you two gold bricks and a whole box of gems. YOU WON THE GREEDY WAY!!!");
  }else if (q5=="capture"){
    alert("You captured the thief and called the poliece you described the thief as if he was a very vicious beast 'everything clean and tidy' you thought to yourself. Just then the door fell off and ten poliece officers charged in. Five surrounded you and pushed you to the wall. Three pointed you with a pistol and the rest of all went to untie the thief's ropes!!! 'but...'you were too confused. 'Hand in the things you stole,THIEF' The poliece officer shouted at you. 'You must have mistaken...'you said.'ABSOULOUTELY NO MISTAKE YOU THIEF. EVERY THIEF WOULD HAVE SAID THAT IT WAS A MISTAKE!!!!! Well a few days later you were on court and it seems that the poliece office have to pay you nine hundred thousand dollars!!! for the mistake and for releasing the thief by mistake YOU WON THE RICH PEOPLES' WAY!!!");
  }//q5 else if
 }else if (q4=="punch"){
   var q4a=prompt ("HUAAAHAAHHAAAHHWWHW you absouloutely won the thief. But you punched a bit too hard that the thief...fell out of the windows! you would be considered as murder! You can stay in hong kong and be captured to garenteen no excuation or escape to china with a speed boat. Type in hk/china");
   if(q4a=="hk") {
     alert("You were considered only self defence and the judge see you as feeling resposible for what you did also because of your sorry and the thief is teresspassing considering all these reasons the judge decided your heart is kind and considered you as an rare exception...you were sentenced in jial for three years only!!! YOU WON THE GOOD PERSON'S WAY");
   }else if(q4a=="china"){
     alert("you hired a 'speed' boat considering wooden fisherman boats would look less suspicious. so,you hired a boat which looks as if it would nver made it to a km. And well never judge a book with it's cover. The boat made an amazing result!!! That was so unbelieveable that it...sank travelling no more than a hundred meters! wow...you are running out of breath. But well, at least you would go to heaven...YOU WON THE SAD WAY")
 }
 }
  else if(q4=="kick"){
alert("well you should never perform a high kick without training. Yes, you didn't but you kinda want to perform a spinning-high-jump-flip-kick and you sucessfully made the trick, kicked the thief but landed in a disaster. Your body couldn't move forever because you have broken the spine. YOU WON THE KUNG-FU MASTER'S WAY and THE BED LOVER'S WAY.");
}//else if q4   
}//end of q2 spray else if 
else if(q2=="poliece"){
  var q2a=prompt ("You must choose a phone but...a new note7 or an old broken phone. Type in note7/ old phone")
  if (q2a=="note7"){
    alert ("with trembling hands you hoped for the best. suddennly you heard footsteps from the corriddor. the thief probbally have a gun... you spanned your note7 in full speed just when you nearly typed the last 9 the thief jumped out of the corner and snatched your phone. 'don't you dare to call the cops' just then the note7 burnt through its shell and blew up right in the thief's hand! The supreme timing and thinking of you made YOU WON THE WISE WAY.");
  }
  else if(q2a=="old phone") {
    alert ("your brick phone nokia is famous for bullet proof and undestructable! surely it wouldn't fail you. Yet, your phone didn't fail you but your charger did. you heard the thief running down the hallway. with fustration, you threw the phone out of the windows with full strength. but your aim was too good and hit the thief right in the head! the thief fell down fainted. YOU WON THE EPIC WAY!");
  }
}//end of q2 else if
 else if (q2=="look"){
   var q2c=prompt ("you saw a thief but the thief punched you right in the face when you look under the bed")
 }
else {
    alert("make sure you followed the typing instructions. please restart game");
}//end of q2 else
}